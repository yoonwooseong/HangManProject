package UserIdCreate;

import java.awt.TextField;
import java.io.Serializable;

public class IdInfo_Path implements Serializable {

	public static String PATH = "C:\\Web_Project\\User_ID\\";
	public static String SCOREPATH = "C:\\Web_Project_file\\User_Score\\";
	
}
